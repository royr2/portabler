fluidPage(

    # Application title
    titlePanel("Segmentation Tool"),

    # Sidebar with a slider input for number of bins
    sidebarLayout(
        sidebarPanel(
          
          # File input
          fileInput("input_file", "Choose CSV File", accept = ".csv"),
          
          # DTREE Engine
          selectInput("dtree_engine", "Select D-Tree Engine", c("RPART", "CTREE"), "RPART"),
          
          # Model inputs
          selectInput("covariates", "X-Vars", choices = NULL, selected = NULL, multiple = T, selectize = T),
          selectInput("dependent", "Y-Var", choices = NULL, selected = NULL, multiple = F, selectize = T),
          
          # Parameters
          tags$b("Model Parameters:"),
          tags$hr(),
          
          numericInput("par_minbucket", "Minbucket", value = 100),
          numericInput("par_maxdepth", "Maxdepth", value = 5),
          numericInput("par_cp", "Cp (RPART)", value = 0.05),
          numericInput("par_mincriterion", "Mincriterion (CTREE)", value = 0.95),
          
          # Model run
          actionButton("run_model", "Fit Model"),
          
        ),

        # Show a plot of the generated distribution
        mainPanel(
          
          # Dtree output
            plotOutput("tree_plot")
        )
    )
)
